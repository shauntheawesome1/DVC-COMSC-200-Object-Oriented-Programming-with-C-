#include "NavyShip.h"
#include <iostream>
#include <string>
using namespace std;

//Empty Constructor: Initialized with Random Values
NavyShip::NavyShip(){
  setType("Aircraft Carrier");
  setDesig("CVN-001");
  setCrewSize(1000);
  setNuclearStatus(true);
  setMaxSpeed(100);
}
//Overloaded Constructor: First 5 args piped to Base Class loaded constructors
NavyShip::NavyShip(string newRegistry, string newHomeport, string newName, int newLength, int newDisplacement, string newType, string newDesig, int newCrewSize, bool newNuclearStatus, int newMaxSpeed) : Ship(newRegistry, newHomeport, newName, newLength, newDisplacement){
  setType(newType); 
  setDesig(newDesig);
  setCrewSize(newCrewSize);
  setNuclearStatus(newNuclearStatus);
  setMaxSpeed(newMaxSpeed);
}

void NavyShip::setType(string newType){
  type = newType;
}

void NavyShip::setDesig(string newDesig){
  desig = newDesig;
}

void NavyShip::setCrewSize(int newCrewSize){
  crewSize = newCrewSize;
}

void NavyShip::setNuclearStatus(bool newNuclearStatus){
  nuclearStatus = newNuclearStatus;
}

void NavyShip::setMaxSpeed(int newMaxSpeed){
  maxSpeed = newMaxSpeed;
}
	
	