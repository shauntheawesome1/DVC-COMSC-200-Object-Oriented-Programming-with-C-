#include "Ship.h"
#include <iostream>
#include <string>
using namespace std;

//Empty Constructor: Initialized with Random Values
Ship::Ship(){
  setRegistry("US");
  setHomeport("Seattle");
  setName("Nameless");
  setLength(500);
  setDisplacement(5000);
	
}
//Overloaded Constructor: First 5 args piped to Base Class loaded constructors
Ship::Ship(string newRegistry, string newHomeport, string newName, int newLength, int newDisplacement){
  setRegistry(newRegistry);
  setHomeport(newHomeport);
  setName(newName);
  setLength(newLength);
  setDisplacement(newDisplacement);
}

void Ship::setRegistry(string newRegistry){
  registry = newRegistry;
}

void Ship::setHomeport(string newHomeport){
  homeport = newHomeport;
}

void Ship::setName(string newName){
  name = newName;
}

void Ship::setLength(int newLength){
  length = newLength;
}

void Ship::setDisplacement(int newDisplacement){
  displacement = newDisplacement;
}