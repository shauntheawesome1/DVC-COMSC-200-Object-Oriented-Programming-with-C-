/*
-------------------------------------------
            NavyShip::Ship
-------------------------------------------
- type : string
- desig : string
- crewSize : int
- nuclearStatus : bool
- maxSpeed : int
-------------------------------------------
+ NavyShip()
+ NavyShip(string, string, string, int, int, string, string, int, bool, int);
+ getType() : string
+ setType(t: string) : void
+ getDesig() : string
+ setDesig(d: string) : void
+ getCrewSize() : int
+ setCrewSize(c: int) : void
+ getNuclearStatus() : bool
+ setNuclearStatus(n: bool) : void
+ getMaxSpeed() : int
+ setMaxSpeed(m: int) : void
-------------------------------------------*/
#ifndef NAVYSHIP_H
#define NAVYSHIP_H
#include "Ship.h"
#include <string>
using namespace std;

class NavyShip : public Ship{
  private:
	string type, desig;
	int crewSize, maxSpeed;
	bool nuclearStatus;
	
  public:
	NavyShip();
	NavyShip(string, string, string, int, int, string, string, int, bool, int);
	
	string getType(){return type;}
	void setType(string);
	
	string getDesig(){return desig;}
	void setDesig(string);
	
	int getCrewSize(){return crewSize;}
	void setCrewSize(int);
	
	bool getNuclearStatus(){return nuclearStatus;}
	void setNuclearStatus(bool);
	
	int getMaxSpeed(){return maxSpeed;}
	void setMaxSpeed(int);
};
#endif