#include "Ship.h"
#include "Ship.cpp"
#include "Ferry.h"
#include "Ferry.cpp"
#include "NavyShip.h"
#include "NavyShip.cpp"
#include <iostream>
#include <string>

using namespace std;

int main(){
  // Programmer's identification
  cout << "Programmer: Shaun Munshi\n";
  cout << "Programmer's ID: 1706828\n";
  cout << "File: " << __FILE__ << endl;
  cout << "\n\n" << endl;
	
/*Test Code:
	
  Ship s1;
  Ship s2("US", "Seattle", "Faithful", 440, 4860);
	
  Ferry f1;
  Ferry f2("US", "Seattle", "Faithful", 440, 4860, 2000, 150, "San Diego", "Santa Cruz", 50.50);
	
  NavyShip ns1;
  NavyShip ns2("US", "Seattle", "Faithful", 440, 4860, "Aircraft Carrier", "CVN-001", 1000, true, 100);
*/

  const int ARR_SIZE = 2;
  
  Ferry ferryShips[ARR_SIZE] = {
	Ferry("US", "Seattle", "Walla-Walla", 440, 4860, 2000, 188, "Edmonds", "Kingston", 35.95),    
	Ferry("US", "Seattle", "Samish", 362, 4320, 1500, 144, "Anacortes", "Friday Harbor", 45.95)
  }; 
 
  NavyShip navyShips[ARR_SIZE] = {
	NavyShip("US", "Yokosuka", "USS John McCain", 505, 8900, "Destroyer", "DDG-56", 281, false, 35),  
	NavyShip("US", "Yokosuka", "USS Ronald Reagan", 1092, 101400, "Aircraft Carrier", "CVN-76", 3532, true, 40)
  };
  
  for(int i = 0; i < ARR_SIZE; i++){
	cout << "Information for Ferry " << ferryShips[i].getName() << ":" << endl;
    cout << "\t > Registry: " << ferryShips[i].getRegistry() << endl;
    cout << "\t > Homeport: " << ferryShips[i].getHomeport() << endl;
    cout << "\t > Length: " << ferryShips[i].getLength() << endl;
    cout << "\t > Displacement: " << ferryShips[i].getDisplacement() << endl;
    cout << "\t > Passenger Capacity: " << ferryShips[i].getPassCap() << endl;
    cout << "\t > Car Capacity: " << ferryShips[i].getCarCap() << endl;
    cout << "\t > Origin: " << ferryShips[i].getOrigin() << endl;
    cout << "\t > Destination: " << ferryShips[i].getDestination() << endl;
    cout << "\t > Ticket Price: " << ferryShips[i].getTicketPrice() << endl;
    cout << "\n\n " << endl;  
  }
  
  for(int j = 0; j < ARR_SIZE; j++){
	cout << "Information for Navy Ship " << navyShips[j].getName() << ":" << endl;
    cout << "\t > Registry: " << navyShips[j].getRegistry() << endl;
    cout << "\t > Homeport: " << navyShips[j].getHomeport() << endl;
    cout << "\t > Length: " << navyShips[j].getLength() << endl;
    cout << "\t > Displacement: " << navyShips[j].getDisplacement() << endl;
    cout << "\t > Type: " << navyShips[j].getType() << endl;
    cout << "\t > Designation: " << navyShips[j].getDesig() << endl;
    cout << "\t > Crew Size: " << navyShips[j].getCrewSize() << endl;
    cout << "\t > Nuclear: " << navyShips[j].getNuclearStatus() << endl;
    cout << "\t > Max Speed: " << navyShips[j].getMaxSpeed() << endl;
    cout << " \n\n " << endl;
  }
  
  cout << "Thank you for using the Ship Generator! Come back any Time :) \n" << endl;
  
}