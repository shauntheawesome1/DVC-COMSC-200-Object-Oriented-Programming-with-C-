/*
-------------------------------------------
			 Ferry::Ship
-------------------------------------------
- passCap : int
- carCap : int
- origin : string
- destination : string
- ticketPrice : double
-------------------------------------------
+ Ferry()
+ Ferry(string, string, string, int, int, int, int, string, string, double)
+ getPassCap() : int
+ setPassCap(p: string) : void
+ getCarCap() : int
+ setCarCap(c: int) : void
+ getOrigin() : string
+ setOrigin(o: string) : void
+ getDestination() : string
+ setDestination(d: string) : void
+ getTicketPrice() : double
+ setTicketPrice(t: double) : void
-------------------------------------------*/
#ifndef FERRY_H
#define FERRY_H
#include "Ship.h"
#include <string>
using namespace std;

class Ferry : public Ship{
  private:
	int passCap, carCap;
	string origin, destination;
	double ticketPrice;
	
  public:
	Ferry();
	Ferry(string, string, string, int, int, int, int, string, string, double);
	
	int getPassCap(){return passCap;}
	void setPassCap(int);
	
	int getCarCap(){return carCap;}
	void setCarCap(int);
	
	string getOrigin(){return origin;}
	void setOrigin(string);
	
	string getDestination(){return destination;}
	void setDestination(string);
	
	double getTicketPrice(){return ticketPrice;}
	void setTicketPrice(double);
};
#endif