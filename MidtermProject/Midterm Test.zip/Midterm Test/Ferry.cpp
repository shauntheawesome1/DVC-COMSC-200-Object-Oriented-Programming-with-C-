#include "Ferry.h"
#include <iostream>
#include <string>
using namespace std;

//Empty Constructor: Initialized with Random Values
Ferry::Ferry(){
  setPassCap(2000);
  setCarCap(150);
  setOrigin("San Diego");
  setDestination("Santa Cruz");
  setTicketPrice(50.50);
}
//Overloaded Constructor: First 5 args piped to Base Class loaded constructors
Ferry::Ferry(string newRegistry, string newHomeport, string newName, int newLength, int newDisplacement, int newPassCap, int newCarCap, string newOrigin, string newDestination, double newTicketPrice) : Ship(newRegistry, newHomeport, newName, newLength, newDisplacement){
  setPassCap(newPassCap);
  setCarCap(newCarCap);
  setOrigin(newOrigin);
  setDestination(newDestination);
  setTicketPrice(newTicketPrice);
}

void Ferry::setPassCap(int newPassCap){
  passCap = newPassCap;
}

void Ferry::setCarCap(int newCarCap){
  carCap = newCarCap;
}

void Ferry::setOrigin(string newOrigin){
  origin = newOrigin;
}

void Ferry::setDestination(string newDestination){
  destination = newDestination;
}

void Ferry::setTicketPrice(double newTicketPrice){
  ticketPrice = newTicketPrice;
}



	
	
	