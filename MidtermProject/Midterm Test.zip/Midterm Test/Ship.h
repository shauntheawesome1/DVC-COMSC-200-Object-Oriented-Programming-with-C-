/*
-------------------------------------------
				Ship
-------------------------------------------
- registry : string
- homeport : string
- name : string
- length : int
- displacement : int
-------------------------------------------
+ Ship()
+ Ship(string, string, string, int, int)
+ getRegistry() : string
+ setRegistry(r: string) : void
+ getHomeport() : string
+ setHomeport(h: string) : void
+ getName() : string
+ setName(n: string) : void
+ getLength() : int
+ setLength(l: int) : void
+ getDisplacement() : int
+ setDisplacement(d: int) : void
-------------------------------------------*/
#ifndef SHIP_H
#define SHIP_H
#include <string>
using namespace std;

class Ship{
  private:
	string registry, homeport, name;
	int length, displacement;
	
  public:
	Ship();
	Ship(string, string, string, int, int);
	
	string getRegistry(){return registry;}
	void setRegistry(string);
	
	string getHomeport(){return homeport;}
	void setHomeport(string);
	
	string getName(){return name;}
	void setName(string);
	
	int getLength(){return length;}
	void setLength(int);
	
	int getDisplacement(){return displacement;}
	void setDisplacement(int);
};
#endif